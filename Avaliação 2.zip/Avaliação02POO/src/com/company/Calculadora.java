package com.company;

public class Calculadora {
    int a;
    int b;
    public int calcular(int a, int b)
    {
        return a + b;
    }

    public Calculadora(int a, int b){
        this.a = a;
        this.b = b;
    }
}