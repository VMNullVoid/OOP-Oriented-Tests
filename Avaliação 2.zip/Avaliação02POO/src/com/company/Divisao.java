package com.company;

public class Divisao extends Calculadora {
    @Override
    public int calcular(int a, int b)
    {
        int resultado = a / b;
        return resultado;
    }
    public double calcular(double a, double b)
    {
        double resultado = a / b;
        return resultado;
    }
    public Divisao(int a, int b) {
        super(a, b);
    }
}
