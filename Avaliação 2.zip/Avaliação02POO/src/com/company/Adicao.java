package com.company;

public class Adicao extends Calculadora {
    public int calcular(int a, int b)
    {
        int resultado = super.calcular(a,b);
        return resultado;
    }

    public double calcular(double a, double b)
    {
        double resultado = a + b;
        return resultado;
    }
    public Adicao(int a, int b) {
        super(a, b);
    }
}
