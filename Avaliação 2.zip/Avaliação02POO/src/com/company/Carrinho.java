package com.company;

import java.util.ArrayList;
import java.util.List;

public class Carrinho {
    List<Carrinho> carrinho = new ArrayList<>();

    public void add(Livro l){

    }
    public void add(Mouse m){

    }
    public void getDescricao(Produto a) {

    }
}

