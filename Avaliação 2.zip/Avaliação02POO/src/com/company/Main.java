package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {
    //////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////
    //    QUESTÕES NÃO RELACIONADAS A CODIGO NO FINAL
    /////////////////////////////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////
    public static void main(String[] args) {
  Carrinho sacola = new Carrinho();
  Mouse m1 = new Mouse("submarinho",120,"1","Mouse ótico, Saída USB. 1.600 dpi");
        Mouse m2 = new Mouse("Carrefour",122,"1","Mouse ótico, Saída USB. 1.600 dpi");
        Livro l1 = new Livro("Saraiva", 70, "Livro infantil");
        Livro l2 = new Livro("Mercado Livre", 100, "Livro de aventura");
        sacola.add(m1);
        sacola.add(m2);
        sacola.add(l1);
        sacola.add(l2);
    }
}
/*1)
a- (2 pontos) - Identifique e apresente os elementos que caracterizam herança e polimorfismo;
Resposta:
O termo Extends em: "public class Corrente extends Conta", a referência a atributos de super classe
em: "super(codigo);super.transferir(valor, conta);" e "super.transferir(valor, conta);", além do
Override em "@Override
             public void sacar(double valor)".

b- (3 pontos) - Apresente uma possível classe Conta que seja compatível para a classe Corrente. Logo, a classe Corrente,
        deverá conformar com a classe Conta, respeitando todos os pilares de POO.
------------------------------------------------------------------------------------------------------------------------
2)
4- Quais os nomes dados às criações de métodos realizadas no tópico 2 e 3? Explique a diferença.
No tópico 2 o nome é Override, já no tópico 3 é Overload. O Override consiste em utilizar uma estrutura semelhante à Super,
nos parâmetros recebidos, porém efetuar operações diferentes das originais. Já o Overload consiste em escrever métodos de
mesmo nome, porém com diferentes assinaturas(parâmetros, variando em tipo, quantidade ou valor).

---------------------------------------------------------------------------------------------------------------------------

Questão 1 (5 pontos): Observe a classe abaixo e faça:
public class Corrente extends Conta {
public Corrente(int codigo) {
super(codigo);
}
@Override
public void sacar(double valor) {
double juros = getSaldo() * 0.01;
sacar(valor, juros);
}
public void transferir(double valor, Poupanca conta) {
super.transferir(valor, conta);
}
public void transferir(double valor, Corrente conta) {
super.transferir(valor, conta);
}
}
a) (2 pontos) - Identifique e apresente os elementos que caracterizam herança e polimorfismo
b) (3 pontos) - Apresente uma possível classe Conta que seja compatível para a classe Corrente.
Logo, a classe Corrente, deverá conformar com a classe Conta, respeitando todos os pilares de
POO.

Questão 2 (5 pontos): Observe a classe abaixo e faça:
public class Calculadora {
public int calcular(int a, int b)
{
return a + b;
}
}
1) Implemente subclasses de Multiplicação, Divisão, Subtração e Adição que herdam da classe
Calculadora.
2) Para cada subclasse, Considere a forma de realizar o cálculo específico de cada classe. Exemplo:
O Método calcular na classe Subtração deverá realizar a subtração de a - b. O Método calcular na
classe Multiplicação deverá realizar a multiplicação de a * b.
3) Escreva também, para cada subclasse, um método capaz de realizar o cálculo considerando
valores decimais.
4) Quais os nomes dados às criações de métodos realizadas no tópico 2 e 3? Explique a diferença.

Questão 3 (5 pontos): Implemente o problema abaixo:
1) lmplemente uma classe “Produto” que possua os atributos “nomeloja” e “preco”, crie os métodos
sets e gets para estes atributos. Crie também o atributo “descricao” e seu método chamado
“getDescricao” que retorna uma String com o simples conteúdo “Produto de informática”.
2) Crie duas classes filhas de “Produto”, que serão “Mouse” com o atributo “tipo” e “Livro” com o
atributo “autor”. No construtor de cada uma dessas classes passe como argumento a descrição
desse produto, por exemplo, Mouse(“Mouse ótico, Saída USB. 1.600 dpi”); Sobrescreva o método
“getDescricao” que retorna a descrição que foi passada no argumento do construtor concatenada
com o atributo que a classe tiver, exemplo: “autor” no caso de livro e “tipo” no caso de mouse. Este
método deve ter a mesma assinatura do método “getDescricao” da classe pai “Produto”.
3) Crie uma classe para o método main que irá simular a compra de um cliente de vários mouses e
livros. Sendo assim, deve haver apenas um vetor/lista na classe para armazenamento de todos os
livros e mouses. Esse vetor/lista deve se chamar “carrinho” que simula o carrinho de compras de
produtos variados de um cliente em um e-commerce. Insira nesse “carrinho” vários mouses e livros
e depois chame o método “getDescricao” de todos os objetos presentes no vetor/lista para o usuário
do carrinho saber as informações dos produtos em seu carrinho.
















































        */
