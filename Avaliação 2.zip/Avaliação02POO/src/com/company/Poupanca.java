package com.company;

public class Poupanca {
    private double dinheiro;
    public Poupanca(double dinheiro){
        this.dinheiro = dinheiro;
    }

    public double getDinheiro() {
        return dinheiro;
    }

    public void setDinheiro(double dinheiro) {
        this.dinheiro += dinheiro;
    }
}
