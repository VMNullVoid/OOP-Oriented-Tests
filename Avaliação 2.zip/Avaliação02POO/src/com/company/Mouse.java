package com.company;

public class Mouse extends Produto{
    public String tipo;
    public String desc = "Mouse ótico, Saída USB. 1.600 dpi";
    public Mouse(String nomeloja, double preco, String tipo, String desc) {
        super(nomeloja, preco);
        this.desc = desc;
    }
    @Override
    public String getDescricao(String dasd) {
        Produto p = new Produto(getNomeloja(), getPreco());
        return desc + tipo;
    }
}
