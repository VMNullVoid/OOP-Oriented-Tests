package com.company;

public class Livro extends Produto {
    public String autor;
    public String descr = "Livro infantil";
    public Livro(String nomeloja, double preco, String descricao) {
        super(nomeloja, preco);
    }
    @Override
    public String getDescricao(String desc) {
        Produto p = new Produto(getNomeloja(), getPreco());
        return descr + autor;
    }
}
