package com.company;

import java.util.Scanner;

public class Conta {
    Scanner ler = new Scanner(System.in);
   public int codigo;
   private double valor;
   private double saldo;

    public double getSaldo() {
        return saldo;
    }

    public void sacar(double valor) {
        double juros = getSaldo() * 0.01;
        System.out.println("Valor sacado com sucesso.\nSaldo atual: " + saldo);
    }

    public void transferir(double valor, Poupanca conta) {
       System.out.println("Informe o valor a ser depositado: ");
       valor = LerValorDouble(ler);
       conta.setDinheiro(valor);
    }

    private double LerValorDouble(Scanner ler) {
        double aux;
       aux = (double) LerValorInt( ler);
       return aux;
    }

    public static int LerValorInt(Scanner ler){
        Scanner valor = new Scanner(System.in);
        return valor.nextInt();
    }
    public static String LerValorString(){
        Scanner valor = new Scanner(System.in);
        return valor.nextLine();
    }
}
