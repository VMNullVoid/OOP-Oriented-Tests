package com.company;

public class ContaFisica extends ContaImpl{
    private Pessoa pessoa;
    @Override
    public void sacar(double valor) {
        if(valor < saldo) {
            double aux = (saldo / 100) * 2;
            saldo -= aux;
            System.out.println("O valor " + valor + " foi sacado. Restante: " + saldo);
        }
        else
            System.out.println("Operação inválida. Saldo insuficiente. Saldo atual desta conta: " + saldo);
    }
    @Override
    public void depositar(double valor) {
        if(valor >=1) {
            saldo += valor;
            System.out.println("Operação concluida. Saldo atual: " + saldo);
        }
        else
            System.out.println("Operação inválida.");
    }


    public ContaFisica(int codigo, double saldo) {
        super(codigo, saldo);
    }
}
