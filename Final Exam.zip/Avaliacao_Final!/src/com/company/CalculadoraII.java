package com.company;

public interface CalculadoraII extends Calculadora {
    //Solução da 2-B
}
