package com.company;

public abstract class ContaImpl implements Conta {
    protected int codigo;
    protected double saldo;

    public double getSaldo() {
        return saldo;
    }
    @Override
    public void sacar(double valor) {
        if(valor < saldo)
     System.out.println("O valor " + valor + " foi sacado. Restante: " + saldo);
        else
            System.out.println("Operação inválida. Saldo insuficiente. Saldo atual desta conta: " + saldo);
    }

    @Override
    public void depositar(double valor) {
     if(valor >=1) {
         saldo += valor;
         System.out.println("Operação concluida. Saldo atual: " + saldo);
     }
     else
         System.out.println("Operação inválida.");
    }

    @Override
    public void transferir(double valor, Conta ContaDestino) {
    ContaDestino.depositar(valor);
    }

    @Override
    public void transferir(double valor, Conta ContaOrigem, Conta ContaDestino) {
        if(valor >=1 ) {
            ContaOrigem.sacar(valor);
            ContaDestino.depositar(valor);
            System.out.println("Operação concluida.");
        }
        else
            System.out.println("Operação inválida.");
    }

    public ContaImpl(int codigo, double saldo){
        this.saldo = saldo;
        this.codigo = codigo;
    }
}
