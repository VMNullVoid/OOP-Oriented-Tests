package com.company;

public interface Conta {
    public void sacar(double valor);
    public void depositar(double valor);
    public void transferir(double valor, Conta ContaDestino);
    public void transferir(double valor, Conta ContaOrigem, Conta ContaDestino);
}
