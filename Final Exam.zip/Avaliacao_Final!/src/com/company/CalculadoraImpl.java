package com.company;
//Solução da 2-A
public class CalculadoraImpl implements Calculadora {
    @Override
    public int calcular(int a, int b) {
        //faria o cálculo aqui e retornaria na linha abaixo
        return 0;
    }

    @Override
    public double calcular(double a, double b) {
        //faria o cálculo aqui e retornaria na linha abaixo
        return 0;
    }
}
