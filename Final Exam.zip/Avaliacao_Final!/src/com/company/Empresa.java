package com.company;

public class Empresa {
    private int codigo = 0;
    private String nome;
    private String cnpj;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getCnpj() {
        return cnpj;
    }

    public Empresa(int codigo, String nome, String cnpj){
        this.nome = nome;
        this.cnpj = cnpj;
        this.codigo = codigo++;
    }
}
