package com.company;
 /*
 QUESTÕES CONCEITUAIS E DE MARCAR ABAIXO DO MAIN
  */
public class Main {

    public static void main(String[] args) {
	// write your code here
    }
}
/*
|-----------------------------------------------------------------------------------------------------|
a) (6 pontos) Implemente na linguagem Java o diagrama representado acima. Utilize seus
conhecimentos sobre POO para que a implementação esteja o mais fiel ao diagrama representado.
Para isso, considere:
1. Complemente sua implementação com os pilares de abstração, encapsulamento, herança e
polimorfismo, que deverão ser identificados e adicionados;
2. Ao sacar, uma Conta Física deverá descontar 2% do valor a ser sacado e uma Conta
Jurídica deverá descontar 4% do valor a ser sacado;
3. A classe ContaImpl não poderá ser instanciada;

b) (2 pontos) Quais as relações entre <<interface>> Conta, ContaImpl, ContaFisica e ContaJuridica?
A interface Conta estabelece o contrato a ser formado conforme às principais características que uma
conta deve ter; A classe ContaImpl implementa essa interface, estabelecendo métodos que atendam ao contrato;
ContaFisica por sua vez personaliza certos métodos de ContaImpl, assim como ContaJuridica tambem personaliza, mas
seguindo as exigências tomadas em relação a uma empresa.

c) (2 pontos) Quais as relações entre Pessoa e ContaFisica, Empresa e ContaJuridica, Banco e
ContaFisica e ContaJuridica?
Pessoa possui uma ContaFisica, assim como Empresa possui uma ContaJuridica.
Banco possui uma lista de contas, que podem ser do tipo ContaFisica ou ContaJuridica.

d) (2 pontos) Descreva detalhes de como podemos implementar a classe ContaImpl, considerando
que ela não pode ser instanciada. Explique!
A classe ContaImpl não pode ser implementada diretamente, por ser classe abstrata. No entanto, ela é a superclasse
de ContaFisica e ContaJuridica, portanto basta utilizar um dos dois tipos ao instanciar certa conta.

e) (3 pontos) Avalie a implementação abaixo e apresente os resultados de contaA, contaF e contaJ:
contaA: Saldo 0
contaF: Saldo 0
contaJ: Saldo 204
|-----------------------------------------------------------------------------------------------------|
Questão 3 (10 pontos): Marque V para as questões Verdadeiras ou F para as Falsas.
(F) - Uma classe sempre deverá conter atributos e métodos.
(F) - Atributos não podem ser públicos.
(F) - Métodos devem ser privados.
(V) - Uma subclasse também poderá ser uma superclasse.
(V) - Devemos herdar uma classe através do extends
(V) - Devemos cirar um poliformismo através do super
(F) - Polimorfimo de sobrecarga nos permite criar métodos iguais com a mesma assinatura
(F) - Podemos sobrescrever um método que não está sendo herdado
(V) - Uma classe abstrata não pode ser instanciada
(F) - Uma classe estática pode ser instanciada
(V) - Uma classe abstrata pode ser herdada
(V) - Uma classe estática não pode ser herdada
(V) - Uma classe abstrata utiliza o modificador abstract
(V) - Uma classe estática utiliza o modificador static
(F) - Uma classe abstrata sempre será uma superclasse
(F) - Em uma classe abstrata todos os métodos devem ser abstratos
(F) - Um único método abstrato pode existir em uma classe não abstrata
(V) - Em uma classe estática todos os membros devem ser estáticos
(F) - Uma interface define uma série de métodos e suas implementações
(F) - Devemos implementar uma interface através do interfaces
|----------------------------------------------------------------------------------------------------|

QUESTÕES DA PROVA ABAIXO:

Questão 1 (15 pontos): Considere o diagrama de classes abaixo e faça:

a) (6 pontos) Implemente na linguagem Java o diagrama representado acima. Utilize seus
conhecimentos sobre POO para que a implementação esteja o mais fiel ao diagrama representado.
Para isso, considere:
1. Complemente sua implementação com os pilares de abstração, encapsulamento, herança e
polimorfismo, que deverão ser identificados e adicionados;
2. Ao sacar, uma Conta Física deverá descontar 2% do valor a ser sacado e uma Conta
Jurídica deverá descontar 4% do valor a ser sacado;
3. A classe ContaImpl não poderá ser instanciada;

b) (2 pontos) Quais as relações entre <<interface>> Conta, ContaImpl, ContaFisica e ContaJuridica?

c) (2 pontos) Quais as relações entre Pessoa e ContaFisica, Empresa e ContaJuridica, Banco e
ContaFisica e ContaJuridica?

d) (2 pontos) Descreva detalhes de como podemos implementar a classe ContaImpl, considerando
que ela não pode ser instanciada. Explique!

e) (3 pontos) Avalie a implementação abaixo e apresente os resultados de contaA, contaF e contaJ:
Conta contaF = new ContaFisica();
Conta contaJ = new ContaJuridica();
Conta contaA = contaF;
contaF.depositar(100);
contaF.sacar(50);
contaJ.depositar(200);
contaJ.sacar(70);
contaF = contaJ;
contaF.depositar(100);
contaF.sacar(50);
contaF = contaA;
contaJ.depositar(200);
contaJ.sacar(70);

Questão 2 (5 pontos): Sobre a interface abaixo, faça:
public interface Calculadora {
int calcular(int a, int b)
double calcular(double a, double b)
}
a) Crie uma classe para implementar esta interface
b) Apresente uma outra interface que permita herdar a interface acima
c) Apresente a mesma solução da interface Calculadora utilizando uma classe abstrata

Questão 3 (10 pontos): Marque V para as questões Verdadeiras ou F para as Falsas.
( ) - Uma classe sempre deverá conter atributos e métodos.
( ) - Atributos não podem ser públicos.
( ) - Métodos devem ser privados.
( ) - Uma subclasse também poderá ser uma superclasse.
( ) - Devemos herdar uma classe através do extends
( ) - Devemos cirar um poliformismo através do super
( ) - Polimorfimo de sobrecarga nos permite criar métodos iguais com a mesma assinatura
( ) - Podemos sobrescrever um método que não está sendo herdado
( ) - Uma classe abstrata não pode ser instanciada
( ) - Uma classe estática pode ser instanciada
( ) - Uma classe abstrata pode ser herdada
( ) - Uma classe estática não pode ser herdada
( ) - Uma classe abstrata utiliza o modificador abstract
( ) - Uma classe estática utiliza o modificador static
( ) - Uma classe abstrata sempre será uma superclasse
( ) - Em uma classe abstrata todos os métodos devem ser abstratos
( ) - Um único método abstrato pode existir em uma classe não abstrata
( ) - Em uma classe estática todos os membros devem ser estáticos
( ) - Uma interface define uma série de métodos e suas implementações
( ) - Devemos implementar uma interface através do interfaces
 */
