package com.company;

import java.util.List;

public class Banco {
    private int codigo;
    private String nome;
    private List<ContaImpl> Contas;

}
