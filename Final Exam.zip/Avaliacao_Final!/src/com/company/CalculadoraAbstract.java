package com.company;
//Solução da 2-C
public abstract interface CalculadoraAbstract {

    public interface Calculadora {
        int calcular(int a, int b);
        double calcular(double a, double b);
    }
}
