package com.company;

public interface Calculadora {
    int calcular(int a, int b);
    double calcular(double a, double b);
}
