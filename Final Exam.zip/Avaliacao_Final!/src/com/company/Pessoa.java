package com.company;

public class Pessoa {
    private int codigo = 0;
    private String nome;
    private String cpf;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getCpf() {
        return cpf;
    }

    public Pessoa(int codigo, String nome, String cnpj){
        this.nome = nome;
        this.cpf = cnpj;
        this.codigo = codigo++;
    }
}
