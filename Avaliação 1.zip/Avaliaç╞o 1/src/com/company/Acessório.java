package com.company;

public class Acessório {
    public int codigo;
    public String descricao;
    public double valor;
    public int tipo;

    public Acessório(int codigo,String descricao,double valor,int tipo){
        this.codigo = codigo;
        this.descricao = descricao;
        this.valor = valor;
        this.tipo = tipo;
    }
    public void Ligar(){
System.out.println("Acessório ligado");
    }
    public void Desligar(){
System.out.println("Acessório desligado");
    }
}
