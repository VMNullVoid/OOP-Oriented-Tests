package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Questões não relacionadas ao final do Main, comentadas.

        Scanner ler = new Scanner(System.in);
        //Motores
        Motor Chevy = new Motor(0101,"Chevrolet 8 cilindros","01",250);
        Motor Premium = new Motor(0202,"Motor Maclaren","77",550);
        Motor Rotacional = new Motor(0303,"Motor rotacional com turbo","99",800);
        //Acessórios
        Acessório Aerofolio = new Acessório(1111,"Aerofolio feio",1200,1);
        Acessório Capo = new Acessório(2000,"Capô de carbono",5000,2);
        Acessório Turbo = new Acessório(7000,"Turbo pressurizado",3000,4);
        //Carros + Motores + Acessórios
        Carro Camaro = new Carro(0001,"Camaro","Chevrolet",2015);
        Camaro.motor = Chevy;
        Camaro.acessorio.add(Aerofolio);
        Carro P1 = new Carro(0002,"P1","Maclaren",2017);
        P1.motor = Premium;
        P1.acessorio.add(Capo);
        Carro Rx7 = new Carro(0003,"Rx7,","Mazda",2001);
        Rx7.motor = Rotacional;
        Rx7.acessorio.add(Turbo);
    }
}
/*Questão 1 (2 pontos): Quais as vantagens de se trabalhar com Programação Orientada à Objetos? Justifique sua
resposta apresentando as principais diferenças entre Programação Orientada à Objetos e Programação Estruturada.
Resposta:

Programação orientada a objetos é vantajosa ao se comparar com a Estruturada já que com ela podemos
trabalhar utilizando tipos e classes diferenciadas para os mais diversos usos. Podemos personalizar
o modo como resolvemos problemas propostos, desenvolvendo aplicações de modo mais eficiente do que ao
implementar programação Estruturada. Por fim, há ganhos em organização de código e desempenho em criar projetos.


Questão 2 (2 pontos): Explique o que você sabe sobre a Programação Orientada a objetos, explicando e
correlacionando os conceitos de Classes, Tipos Complexos, Atributos, Métodos, Objetos e Instâncias.
Resposta:

Programação orientada a objetos parte do princípio de criação de Classes novas, compostas Tipos Complexos, isto é,
tipos que se originam juntando uma combinação dos mais variados tipos de tipos primitivos de dados como String, int etc.
As Classes criadas podem conter Atributos, Métodos para que haja interação entre ela e o programa. Uma vez "chamada"
no main através da criação de um Objeto da Classe, que pega o método Construtor com todos os atributos base da Classe,
podemos Instanciá-lo, alocando o devido espaço de cada variável na memória, e podendo interagir com o objeto total.


Questão 3 (2 pontos): Defina e explique o pilar de Abstração da Programação Orientada a Objetos. Pensando na
abstração mais alto nível, como você pensaria na definição das classes para os tipos Casa, Animal, Paciente?
Resposta:

O conceito de Abstração, que abrange a Programação Orientada a Objetos, é o conceito que consiste em "abstrair" um objeto
da vida real, de forma a identificar seus atributos e funções e implementar em código.A classe Casa pode ser definida com
atributos como tamanho, número de andares, de portas, janelas, quartos, cor das paredes e tudo que seja relevante para a
solução. Já a classe Animal, pode ser definida por raça, cor, tamanho, sexo, idade, habitat, e por aí vai. Por fim,
 a classe Paciente pode levar em conta o nome, CPF, RG, data de nascimento, tipo sanguíneo, histórico de doenças, cartão de
 vacina, etc.

Questão 4 (9 pontos): Sobre o diagrama de classe abaixo, faça:
c) (1 ponto) Qual a relação entre Carro e Acessorio? E a relação entre Carro e Motor? Explique as duas
relações.

Resposta:

Carro possui necessáriamente um motor, e carro possui um acessório, mas não depende dele. A diferença primordial
consiste nos tipos de dependência de uma classe da outra, ao instanciarmos objetos. No caso do motor o carro depende
totalmente do motor para ser funcional, sendo uma característica fundamental do carro, já o acessório é um bônus, podendo
ou não estar presente no carro. (Esqueci o nome das relações, mas uma é "opcional e a outra obrigatória).


d) (2 pontos) Assinale V (Verdadeiro) ou F (Falso) para cada alternativa:
(F) Através apenas de um dos acessórios de um carro, conseguimos saber a potência do motor
    deste carro
(F) Podemos definir um modelo de um carro através da criação de um tipo complexo Modelo
(V) Um objeto de carro contém a relação para um objeto acessório, e não o contrário.
(V) Para incluir um objeto acessório à um carro, é preciso, primeiramente, instanciar a lista de
    acessórios e utilizar o método add().
(F) Não é possível existir um objeto motor com atributo codigo = 1 e um objeto carro com atributo
codigo = 1.


e) (2 pontos) Como podemos alterar a abstração das classes acima para permitir que através de um objeto de
um motor eu consiga saber todos os acessórios de um carro que possui este mesmo motor?
Resposta:
Seria necessário criar uma lógica na qual o Motor possui um carro, que por sua vez possui um acessório. Poderíamos criar
uma função para exibir os acessórios no main após instanciarmos o motor e o carro, ou tentar chamar diretamente do motor.

f) (2 pontos) Observe o código abaixo:
|------------------------------|
|Motor motor1 = new Motor();   |
|Motor motor2 = new Motor();   |
|Carro carro1 = new Carro();   |
|Carro carro2 = new Carro();   |
|carro1.motor = motor1;        |
|carro2.motor = motor2;        |
|motor1.potencia = 100.0;      |
|motor2.potencia = 200.0;      |
|carro2.motor = carro1.motor;  |
|carro1.motor.potencia = 100.0;|
|carro2.motor.potencia = 200.0;|
|------------------------------|
Ao final do programa, qual a potencia do motor do carro1? E qual a potencia do motor do carro2? Discurse
sobre sua resposta explicando o que sabe sobre o conceito de referencias dos objetos.
Resposta:
Potencia do motor do carro 1: 200.0
Potencia do motor do carro 2: 200.0
Houve anteriormente a atribuição das potências separadamente. No entanto, ao fazer "carro2.motor = carro1.motor;",
carro 2 e carro 1 apontam para a mesma referência de memória, portanto qualquer alteração em um dos objetos resulta na
alteração de ambos. Portanto, a potência dos dois é igual a 200.0  .
 */

