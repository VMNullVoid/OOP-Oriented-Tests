package com.company;

public class Motor {
    public int codigo;
    public String descricao;
    public String tipo;
    public double potencia;

    public Motor(int codigo,String descricao,String tipo,double potencia){
        this.codigo = codigo;
        this.descricao = descricao;
        this.tipo = tipo;
        this.potencia = potencia;
    }
}
