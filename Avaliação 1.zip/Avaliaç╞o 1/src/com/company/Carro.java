package com.company;

import java.util.ArrayList;
import java.util.List;

public class Carro {
    public int codigo;
    public String modelo;
    public String marca;
    public int ano;
    List<Acessório> acessorio = new ArrayList<>();
    public Motor motor;

    public Carro(int codigo,String modelo,String marca,int ano){
        this.codigo = codigo;
        this.modelo = modelo;
        this.marca = marca;
        this.ano = ano;
    }
    public void Ligar(){

    }
    public void Desligar(){

    }
    public void Acelerar(){

    }
}
